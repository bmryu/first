package Assignment3;

import java.io.IOException;
import java.util.ArrayList;

public class JourneyManager {//regnum + detination + price 

	public JourneyManager() {

	}

	public void run() throws IOException {
//		setVcsv();
		Journey J = new Journey();
		J.run();
	
	}
}
