package Assignment3;

import java.io.IOException;

public class Assign3 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		JourneyManager manager = new JourneyManager();
		manager.run();

//		Class with a main method which just creates a manager object and calls its run method
		//	Taxi and Minibus subclasses with an abstract Vehicle superclass. 
	}

}
